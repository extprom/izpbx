<?php
echo FreePBX::Configedit()->showPage();
